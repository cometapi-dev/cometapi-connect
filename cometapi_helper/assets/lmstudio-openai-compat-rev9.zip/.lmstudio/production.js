"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// src/config.ts
var import_sdk, configSchematics, globalConfigSchematics;
var init_config = __esm({
  "src/config.ts"() {
    "use strict";
    import_sdk = require("@lmstudio/sdk");
    configSchematics = (0, import_sdk.createConfigSchematics)().field(
      "model",
      "select",
      {
        displayName: "Model",
        subtitle: "Select the model to use for generation.",
        options: [
          { value: "claude-sonnet-4-20250514", displayName: "claude-sonnet-4-20250514" },
          { value: "claude-opus-4-20250514", displayName: "claude-opus-4-20250514" },
          { value: "gpt-4.1-2025-04-14", displayName: "gpt-4.1-2025-04-14" },
          { value: "gpt-4.1-mini-2025-04-14", displayName: "gpt-4.1-mini-2025-04-14" }
        ]
      },
      "claude-sonnet-4-20250514"
    ).build();
    globalConfigSchematics = (0, import_sdk.createConfigSchematics)().field(
      "openaiApiKey",
      "string",
      {
        displayName: "OpenAI API Key",
        isProtected: true,
        placeholder: "sk-..."
      },
      ""
    ).field(
      "anthropicApiKey",
      "string",
      {
        displayName: "Anthropic API Key",
        isProtected: true,
        placeholder: "ant-..."
      },
      ""
    ).field(
      "overrideBaseUrl",
      "string",
      {
        displayName: "(Optional) Override Base URL",
        subtitle: "Override the base URL for API calls. Leave empty to let the plugin guess the base URL.",
        placeholder: "https://api.example.com/v1"
      },
      ""
    ).build();
  }
});

// src/generator.ts
function createOpenAI(globalConfig, isOpenAIModel) {
  const overrideBaseUrl = globalConfig.get("overrideBaseUrl");
  const baseURL = overrideBaseUrl || (isOpenAIModel ? "https://api.openai.com/v1" : "https://api.anthropic.com/v1");
  const apiKey = isOpenAIModel ? globalConfig.get("openaiApiKey") : globalConfig.get("anthropicApiKey");
  return new import_openai.default({
    apiKey,
    baseURL
  });
}
function toOpenAIMessages(history) {
  const messages = [];
  for (const message of history) {
    switch (message.getRole()) {
      case "system":
        messages.push({ role: "system", content: message.getText() });
        break;
      case "user":
        messages.push({ role: "user", content: message.getText() });
        break;
      case "assistant": {
        const toolCalls = message.getToolCallRequests().map((toolCall) => ({
          id: toolCall.id ?? "",
          type: "function",
          function: {
            name: toolCall.name,
            arguments: JSON.stringify(toolCall.arguments ?? {})
          }
        }));
        messages.push({
          role: "assistant",
          content: message.getText(),
          ...toolCalls.length ? { tool_calls: toolCalls } : {}
        });
        break;
      }
      case "tool": {
        message.getToolCallResults().forEach((toolCallResult) => {
          messages.push({
            role: "tool",
            tool_call_id: toolCallResult.toolCallId ?? "",
            content: toolCallResult.content
          });
        });
        break;
      }
    }
  }
  return messages;
}
function toOpenAITools(ctl) {
  const tools = ctl.getToolDefinitions().map((t) => ({
    type: "function",
    function: {
      name: t.function.name,
      description: t.function.description,
      parameters: t.function.parameters ?? {}
    }
  }));
  return tools.length ? tools : void 0;
}
function wireAbort(ctl, stream) {
  ctl.onAborted(() => {
    console.info("Generation aborted by user.");
    stream.controller.abort();
  });
}
async function consumeStream(stream, ctl) {
  let current = null;
  function maybeFlushCurrentToolCall() {
    if (current === null || current.name === null) {
      return;
    }
    ctl.toolCallGenerationEnded({
      type: "function",
      name: current.name,
      arguments: JSON.parse(current.arguments),
      id: current.id
    });
    current = null;
  }
  for await (const chunk of stream) {
    console.info("Received chunk:", JSON.stringify(chunk));
    const delta = chunk.choices?.[0]?.delta;
    if (!delta) continue;
    if (delta.content) {
      ctl.fragmentGenerated(delta.content);
    }
    for (const toolCall of delta.tool_calls ?? []) {
      if (toolCall.id !== void 0) {
        maybeFlushCurrentToolCall();
        current = { id: toolCall.id, name: null, index: toolCall.index, arguments: "" };
        ctl.toolCallGenerationStarted();
      }
      if (toolCall.function?.name && current) {
        current.name = toolCall.function.name;
        ctl.toolCallGenerationNameReceived(toolCall.function.name);
      }
      if (toolCall.function?.arguments && current) {
        current.arguments += toolCall.function.arguments;
        ctl.toolCallGenerationArgumentFragmentGenerated(toolCall.function.arguments);
      }
    }
    if (chunk.choices?.[0]?.finish_reason === "tool_calls" && current?.name) {
      maybeFlushCurrentToolCall();
    }
  }
  console.info("Generation completed.");
}
async function generate(ctl, history) {
  const config = ctl.getPluginConfig(configSchematics);
  const model = config.get("model");
  const isOpenAIModel = model.startsWith("gpt-");
  const globalConfig = ctl.getGlobalPluginConfig(globalConfigSchematics);
  const openai = createOpenAI(globalConfig, isOpenAIModel);
  const messages = toOpenAIMessages(history);
  const tools = toOpenAITools(ctl);
  const stream = await openai.chat.completions.create({
    model,
    messages,
    tools,
    stream: true
  });
  wireAbort(ctl, stream);
  await consumeStream(stream, ctl);
}
var import_openai;
var init_generator = __esm({
  "src/generator.ts"() {
    "use strict";
    import_openai = __toESM(require("openai"));
    init_config();
  }
});

// src/index.ts
var src_exports = {};
__export(src_exports, {
  main: () => main
});
async function main(context) {
  context.withConfigSchematics(configSchematics);
  context.withGlobalConfigSchematics(globalConfigSchematics);
  context.withGenerator(generate);
}
var init_src = __esm({
  "src/index.ts"() {
    "use strict";
    init_config();
    init_generator();
  }
});

// .lmstudio/entry.ts
var import_sdk2 = require("@lmstudio/sdk");
var clientIdentifier = process.env.LMS_PLUGIN_CLIENT_IDENTIFIER;
var clientPasskey = process.env.LMS_PLUGIN_CLIENT_PASSKEY;
var baseUrl = process.env.LMS_PLUGIN_BASE_URL;
var client = new import_sdk2.LMStudioClient({
  clientIdentifier,
  clientPasskey,
  baseUrl
});
globalThis.__LMS_PLUGIN_CONTEXT = true;
var predictionLoopHandlerSet = false;
var promptPreprocessorSet = false;
var configSchematicsSet = false;
var globalConfigSchematicsSet = false;
var toolsProviderSet = false;
var generatorSet = false;
var selfRegistrationHost = client.plugins.getSelfRegistrationHost();
var pluginContext = {
  withPredictionLoopHandler: (generate2) => {
    if (predictionLoopHandlerSet) {
      throw new Error("PredictionLoopHandler already registered");
    }
    if (toolsProviderSet) {
      throw new Error("PredictionLoopHandler cannot be used with a tools provider");
    }
    predictionLoopHandlerSet = true;
    selfRegistrationHost.setPredictionLoopHandler(generate2);
    return pluginContext;
  },
  withPromptPreprocessor: (preprocess) => {
    if (promptPreprocessorSet) {
      throw new Error("PromptPreprocessor already registered");
    }
    promptPreprocessorSet = true;
    selfRegistrationHost.setPromptPreprocessor(preprocess);
    return pluginContext;
  },
  withConfigSchematics: (configSchematics2) => {
    if (configSchematicsSet) {
      throw new Error("Config schematics already registered");
    }
    configSchematicsSet = true;
    selfRegistrationHost.setConfigSchematics(configSchematics2);
    return pluginContext;
  },
  withGlobalConfigSchematics: (globalConfigSchematics2) => {
    if (globalConfigSchematicsSet) {
      throw new Error("Global config schematics already registered");
    }
    globalConfigSchematicsSet = true;
    selfRegistrationHost.setGlobalConfigSchematics(globalConfigSchematics2);
    return pluginContext;
  },
  withToolsProvider: (toolsProvider) => {
    if (toolsProviderSet) {
      throw new Error("Tools provider already registered");
    }
    if (predictionLoopHandlerSet) {
      throw new Error("Tools provider cannot be used with a predictionLoopHandler");
    }
    toolsProviderSet = true;
    selfRegistrationHost.setToolsProvider(toolsProvider);
    return pluginContext;
  },
  withGenerator: (generator) => {
    if (generatorSet) {
      throw new Error("Generator already registered");
    }
    generatorSet = true;
    selfRegistrationHost.setGenerator(generator);
    return pluginContext;
  }
};
Promise.resolve().then(() => (init_src(), src_exports)).then(async (module2) => {
  return await module2.main(pluginContext);
}).then(() => {
  selfRegistrationHost.initCompleted();
}).catch((error) => {
  console.error("Failed to execute the main function of the plugin.");
  console.error(error);
});
