# OpenAI Adapter for LM Studio

Use any OpenAI-compatible API in LM Studio.
